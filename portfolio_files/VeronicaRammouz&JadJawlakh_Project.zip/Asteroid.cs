﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Outer_Space
{
    public class Asteroid : IDestroyableElement, IMove
    {
        public static int Number;
        public Color color = Color.Brown;
        public void Move(ref Object[,] arr, int x, int y, Random rand)
        {

        }

        public void Crash()
        {
            //if ((SpaceshipA.FuelLevel > 70 && SpaceshipB.FuelLevel > 70) && ((Asteroid == SpaceshipA.Position) || (Asteroid == SpaceshipB.Position) || (Asteroid == SupplyStation.Position))
            //{
            //    // This is a pseudocode to say that the Asteroid that gets hit by a Spaceship A or a SpaceShip B, or that meets with\
            //    // a Supply Station, gets destroyed. 
            //    // The implementation of it must go here... 

            //    // The Asteroid should get split in two 
            //    Asteroid currentAsteroid = *2;
            //    Asteroid.height / 2;

            //}

        }
        public  void Destroy()
        {
            //if ((Asteroid.Position == FuelStation.Position) && (Asteroid.Position = SpaceshipA.Position.FuelLevel < 70) && (Asteroid.Position = SpaceshipB.Position.FuelLevel < 70))
            //{
            //    // Pseudocode to say that if an Asteroid meets a Fuel Station, the Fuel Station gets destroyed. \
            //    // And if an Asteroid meets a SpaceShip A or B whose Fuel Level is below 70, gets destroyed. 

            //    // The implementation of it must go here.. 
            //}
        }


    }
}
