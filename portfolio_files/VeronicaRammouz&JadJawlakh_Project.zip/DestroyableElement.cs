﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Outer_Space
{
    public interface IDestroyableElement
    {
        void Crash();
    }
}
