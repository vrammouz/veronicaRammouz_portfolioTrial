﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Outer_Space;
using System.Drawing;

namespace Outer_Space
{
    public class Element
    {
        public static int height = 20;
        public static int width = 20;
        public static Color color = Color.Gray;
        public static SolidBrush elBrush = new SolidBrush(color);

    }
}
