﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Outer_Space;

namespace Outer_Space
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Draw_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            //form.construct(Convert.ToInt32(numericUpDown1.Value));
            form.ShowDialog();
           
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
         
           NumericUpDown s = sender as NumericUpDown;
           OuterSpace.Width = Convert.ToInt32(s.Value);

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown s = sender as NumericUpDown;
            OuterSpace.Height = Convert.ToInt32(s.Value);
        }

       

        private void numericUpDown5_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown s = sender as NumericUpDown;
            SupplyStation.Number = Convert.ToInt32(s.Value);
        }

        private void numericUpDown6_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown s = sender as NumericUpDown;
            FuelStation.Number = Convert.ToInt32(s.Value);
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown s = sender as NumericUpDown;
            SpaceshipA.Number = Convert.ToInt32(s.Value);
        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown s = sender as NumericUpDown;
            SpaceshipB.Number = Convert.ToInt32(s.Value);
        }

        private void numericUpDown7_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown s = sender as NumericUpDown;
            Asteroid.Number = Convert.ToInt32(s.Value);
        }
    }
}
