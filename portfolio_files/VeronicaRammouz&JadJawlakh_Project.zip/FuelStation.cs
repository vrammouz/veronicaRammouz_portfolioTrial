﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Outer_Space
{
    public class FuelStation : IDestroyableElement
    {
        public static int Number;
        Color color = Color.Teal;
      
        //public void Crash()
        //{
        //  if (FuelStation.Position==Asteroid.Position)
        //    {
        //        // This is a pseudocode to say that if a Fuel Station is met with an Asteroid,
        //        // the fuel station gets destroyed 

        //  // The implementation of that must go here 
        //    }
        //}

        

    }
}
