﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Outer_Space
{
    public class OuterSpace
    {
        public static int Height;
        public static int Width;
        public static Object [,] arr = new Object [Height, Width];

        public OuterSpace(int width , int height, int spaceshipACount, int spaceshipBCount, int AsteroidsCount, int FuelStation, int SupplyStation)
        {
            Random rand = new Random();
            int d = width * height;

            for (int j= 1; j<=spaceshipACount; j++)
            {
                int row = rand.Next(width);
                int col = rand.Next(height);
                    
                SpaceshipA spA = new SpaceshipA();
                arr[row, col] = spA;

            }

            for (int k=1; k<= spaceshipBCount; k++)
            {
                int row = rand.Next(width);
                int col = rand.Next(height);

                SpaceshipB spB= new SpaceshipB();
                if (arr[row,col] == null)
                   arr[row, col] = spB;

                else
                    spaceshipBCount++;
            }
            
            for (int l=1; l<= AsteroidsCount; l++)
            {
                int row = rand.Next(width);
                int col = rand.Next(height);

                Asteroid A = new Asteroid();

                if (arr[row, col] == null)
                    arr[row, col] = A;
                else
                    AsteroidsCount++;
            }

            for (int m=1; m<= FuelStation; m++)
            {
                int row = rand.Next(width);
                int col = rand.Next(height);

                FuelStation F = new FuelStation();
                if (arr[row, col] == null)
                    arr[row, col] = F;
                else
                    FuelStation++;
            }

            for (int n=1; n<= SupplyStation; n++)
            {
                int row = rand.Next(width);
                int col = rand.Next(height);

                SupplyStation S = new SupplyStation();
                if (arr[row, col] == null)
                    arr[row, col] = S;
                else
                    SupplyStation++;
            }

            for (int i = 0; i < d; i++)
            {
                int row = rand.Next(width);
                int col = rand.Next(height);
                Element element = new Element();

                if (arr[row, col] == null)
                    arr[row, col] = element;
            }
        }
      }
    }