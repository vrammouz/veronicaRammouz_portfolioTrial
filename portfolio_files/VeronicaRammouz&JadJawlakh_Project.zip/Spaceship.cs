﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Outer_Space
{
    public class Spaceship : Element, IDestroyableElement, IDestroy, IMove
    {
        public int Fuel = 100;
        public int Supply = 100;

        public bool isAlive()
        {
            if (Fuel > 0 || Supply > 0)
            {
                return true;
            }
            return false;
        }

        public void Move(ref Object[,] arr, int x, int y, Random rand)
        {
            if (isAlive() == true)
            {
                arr = OuterSpace.arr;
                Fuel -= 5;
                Supply -= 5;

                foreach (Element e in arr)
                {
                    for (int i = 0; i <= arr.Length; i++)
                    {
                        for (int j = 0; j <= arr.Length; j++)
                        {
                            int row = rand.Next(-2, 1);
                            int col = rand.Next(-2, 1);
                            var temp = arr[i, j];
                            arr[i, j] = arr[row, col];
                            arr[row, col] = temp;

                        }

                    }
                }

            }

        }


        public void Destroy()
        { }

        public void Crash()
        { }
    }

    public class SpaceshipA : Spaceship
    {
        public static int Number;
        Color colorA = Color.Purple;
        public static int FuelLevel;
        public static int SupplyLevel;

        //public void Crash()
        //{
        //    if (SpaceshipA.FuelLevel < SpaceshipB.FuelLevel || SpaceshipA.FuelLevel < 70)
        //    {
        //        // SpaceShip A gets destroyed 
        //    }
        //}

        //public void Destroy()
        //{
        //    if (SpaceshipA.FuelLevel > SpaceshipB.FuelLevel && SpaceshipA.FuelLevel > 70)
        //    {
        //        // The SpaceShip A destroys SpaceShip(s) B and/ or Asteroid(s)
        //    }

        //}

        public void Refuel()
        {
            FuelLevel = 100;
         //   if ((SpaceshipA == FuelStation.Position)) 
                // This is a pseudocode to say that if a Spaceship A meets the position of a Fuel Station in the 
                // 2D array, it sets its FuelLevel to 100
        }

        public void ReSupply()
        {
            SupplyLevel = 100;
           // if ((SpaceshipA == SupplyStation.Position))
                        // This is a pseudocode to say that if a Spaceship A meets the position of a Supply Station in the 
                // 2D array, it sets its SupplyLevel to 100
        }



    }
        public class SpaceshipB : Spaceship
        {
            public static int Number;
            Color colorB = Color.Red;
            public static int FuelLevel;
            public static int SupplyLevel;

            //public void Crash()
            //{
            //    if ((SpaceshipB.FuelLevel < SpaceshipA.FuelLevel) || (SpaceshipB.FuelLevel < 70))
            //    {
            //        // The SpaceShip B gets destroyed 
            //    }
            //}

            //public void Destroy()
            //{
            //    if ((SpaceshipB.SupplyLevel > SpaceshipA.SupplyLevel) || (SpaceshipB.SupplyLevel > 70))
            //    {
            //        // The SpaceShip B destroys Spaceship(s) A and/ or Asteroid(s)
            //    }
            //}

        public void Refuel()
        {
            FuelLevel = 100;
            //if ((SpaceshipB==FuelStation.Position)) 
                // This is a pseudocode to say that if a Spaceship B meets the position of a Fuel Station in the 
                // 2D array, it sets its FuelLevel to 100
        }

        public void ReSupply()
        {
            SupplyLevel = 100; 
          //  if ((SpaceshipB==SupplyStation.Position))
                        // This is a pseudocode to say that if a Spaceship B meets the position of a Supply Station in the 
                // 2D array, it sets its SupplyLevel to 100
        }
    }
}
