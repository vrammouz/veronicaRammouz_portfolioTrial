﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Outer_Space
{
    public class SupplyStation : IDestroy
    {
        public static int Number;
        Color color = Color.Yellow;

        public void Destroy()
        {
        //if (SupplyStation.Position==Asteroid.Position)
        //    {
        //        // If Supply Station meets an Asteroid, it destroys the Asteroid 
        //        // The implementation goes here 
        //    }
        }

       
    }
}
